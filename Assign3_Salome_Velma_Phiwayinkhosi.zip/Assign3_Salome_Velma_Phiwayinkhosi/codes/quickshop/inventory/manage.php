<?php
// inventory/manage.php - For inventory managers
require_once '../config.php';
include '../navbar.php';

if (!in_array($_SESSION['role'], ['Administrator', 'Inventory Manager'])) {
    header('Location: ../index.php');
    exit;
}

class InventoryManager {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function updateStock($productId, $quantity) {
        $stmt = $this->db->prepare("UPDATE products SET StockQuantity = ? WHERE ProductID = ?");
        return $stmt->execute([$quantity, $productId]);
    }
    
    public function getInventoryReport() {
        $stmt = $this->db->prepare("
            SELECT p.*, 
                   COALESCE(SUM(od.Quantity), 0) as TotalSold
            FROM products p
            LEFT JOIN orderdetails od ON p.ProductID = od.ProductID
            GROUP BY p.ProductID
            ORDER BY p.StockQuantity ASC
        ");
        $stmt->execute();
        return $stmt->fetchAll();
    }
}

$inventoryManager = new InventoryManager();
$inventory = $inventoryManager->getInventoryReport();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory Management - QuickShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>Inventory Management</h2>
        
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Current Stock</th>
                        <th>Total Sold</th>
                        <th>Price</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($inventory as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['ProductName']) ?></td>
                            <td>
                                <span class="<?= $item['StockQuantity'] < 10 ? 'text-danger' : '' ?>">
                                    <?= $item['StockQuantity'] ?>
                                </span>
                            </td>
                            <td><?= $item['TotalSold'] ?></td>
                            <td>$<?= number_format($item['Price'], 2) ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary update-stock" 
                                    data-product-id="<?= $item['ProductID'] ?>"
                                    data-current-stock="<?= $item['StockQuantity'] ?>">
                                    Update Stock
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Stock Update Modal -->
    <div class="modal fade" id="updateStockModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Update Stock</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="updateStockForm">
                    <div class="modal-body">
                        <input type="hidden" name="product_id" id="productId">
                        <div class="mb-3">
                            <label class="form-label">New Stock Quantity</label>
                            <input type="number" class="form-control" name="quantity" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const modal = new bootstrap.Modal(document.getElementById('updateStockModal'));
            
            document.querySelectorAll('.update-stock').forEach(button => {
                button.addEventListener('click', function() {
                    const productId = this.dataset.productId;
                    const currentStock = this.dataset.currentStock;
                    
                    document.getElementById('productId').value = productId;
                    document.querySelector('[name="quantity"]').value = currentStock;
                    
                    modal.show();
                });
            });
            
            document.getElementById('updateStockForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                
                try {
                    const response = await fetch('update_stock.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: new URLSearchParams(new FormData(this))
                    });
                    
                    const data = await response.json();
                    if (data.success) {
                        location.reload();
                    } else {
                        alert(data.error || 'Update failed');
                    }
                } catch (error) {
                    alert('Error updating stock');
                }
            });
        });
    </script>
</body>
</html>