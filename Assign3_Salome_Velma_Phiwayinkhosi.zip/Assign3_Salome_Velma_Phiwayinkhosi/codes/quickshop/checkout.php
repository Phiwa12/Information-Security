<?php
// checkout.php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header('Content-Type: application/json');
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid checkout attempt']);
    exit;
}

class CheckoutManager {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function processCheckout($userId, $cartItems) {
        $this->db->beginTransaction();
        
        try {
            // Verify stock availability and calculate total
            $total = 0;
            $orderItems = [];
            
            foreach ($cartItems as $productId => $quantity) {
                $stmt = $this->db->prepare("SELECT ProductID, Price, StockQuantity 
                    FROM products WHERE ProductID = ? FOR UPDATE");
                $stmt->execute([$productId]);
                $product = $stmt->fetch();
                
                if (!$product) {
                    throw new Exception("Product not found");
                }
                
                if ($product['StockQuantity'] < $quantity) {
                    throw new Exception("Insufficient stock for product ID: $productId");
                }
                
                $subtotal = $product['Price'] * $quantity;
                $total += $subtotal;
                
                $orderItems[] = [
                    'product_id' => $productId,
                    'quantity' => $quantity,
                    'price' => $product['Price']
                ];
                
                // Update stock
                $stmt = $this->db->prepare("UPDATE products 
                    SET StockQuantity = StockQuantity - ? 
                    WHERE ProductID = ?");
                $stmt->execute([$quantity, $productId]);
            }
            
            // Create order
            $stmt = $this->db->prepare("INSERT INTO orders (UserID, TotalAmount) 
                VALUES (?, ?)");
            $stmt->execute([$userId, $total]);
            $orderId = $this->db->lastInsertId();
            
            // Create order details
            $stmt = $this->db->prepare("INSERT INTO orderdetails 
                (OrderID, ProductID, Quantity, Price) VALUES (?, ?, ?, ?)");
                
            foreach ($orderItems as $item) {
                $stmt->execute([
                    $orderId,
                    $item['product_id'],
                    $item['quantity'],
                    $item['price']
                ]);
            }
            
            // Clear the cart
            $_SESSION['cart'] = [];
            
            $this->db->commit();
            return $orderId;
            
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
}

// Process checkout
header('Content-Type: application/json');

try {
    $checkoutManager = new CheckoutManager();
    $orderId = $checkoutManager->processCheckout($_SESSION['user_id'], $_SESSION['cart']);
    
    echo json_encode([
        'success' => true,
        'order_id' => $orderId,
        'message' => 'Order processed successfully'
    ]);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}