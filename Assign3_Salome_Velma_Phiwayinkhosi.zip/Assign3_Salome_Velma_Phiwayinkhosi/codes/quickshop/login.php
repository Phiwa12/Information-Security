<?php
// login.php
session_start();
require_once 'config.php';

$error = '';
$isSecure = isset($_GET['secure']) ? true : false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if ($isSecure) {
        // Secure version
        $db = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
        $stmt = $db->prepare("SELECT * FROM users WHERE Email = ? AND Password = SHA2(?, 256)");
        $stmt->execute([$email, $password]);
        $user = $stmt->fetch();
        
        if ($user) {
            $_SESSION['user_id'] = $user['UserID'];
            $_SESSION['role'] = $user['Role'];
            $_SESSION['email'] = $user['Email'];
            header('Location: index.php');
            exit;
        } else {
            $error = "Invalid email or password";
        }
    } else {
        // Vulnerable version
        $db = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        $query = "SELECT * FROM users WHERE Email='$email' AND Password=SHA2('$password', 256)";
        $result = mysqli_query($db, $query);
        
        if ($result && mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);
            $_SESSION['user_id'] = $user['UserID'];
            $_SESSION['role'] = $user['Role'];
            $_SESSION['email'] = $user['Email'];
            header('Location: index.php');
            exit;
        } else {
            $error = "Invalid email or password. Try SQL injection: ' OR '1'='1";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - QuickShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <!-- Security Toggle -->
        <div class="text-end mb-3">
            <a href="?<?= $isSecure ? '' : 'secure=1' ?>" class="btn btn-<?= $isSecure ? 'success' : 'danger' ?>">
                Currently: <?= $isSecure ? 'Secure Mode' : 'Vulnerable Mode' ?>
            </a>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Login</h3>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?= $error ?></div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="text" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Login</button>
                            </div>
                        </form>
                        <div class="mt-3 text-center">
                            <p>Don't have an account? <a href="register.php">Register here</a></p>
                        </div>
                        
                        <?php if (!$isSecure): ?>
                            <div class="alert alert-warning mt-3">
                                <h4>🔥 SQL Injection Examples:</h4>
                                <p>Try these in the email field (leave password empty):</p>
                                <code>admin' OR '1'='1</code><br>
                                <code>admin'; --</code><br>
                                <code>' OR '1'='1' -- -</code>
                                <?php if (isset($query)): ?>
                                    <p class="mt-2">Last executed query:</p>
                                    <pre><?= htmlspecialchars($query) ?></pre>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>