<?php
// deploy.php
class Deployer {
    private $db;
    private $errors = [];
    private $success = [];
    
    public function __construct() {
        try {
            $this->db = new PDO(
                "mysql:host=localhost",
                "root",
                ""
            );
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
    }
    
    public function deploy() {
        $this->createDatabase();
        $this->createTables();
        $this->createProcedures();
        $this->insertTestData();
        $this->checkFilePermissions();
        $this->displayResults();
    }
    
    private function createDatabase() {
        try {
            $this->db->exec("CREATE DATABASE IF NOT EXISTS quickshop");
            $this->db->exec("USE quickshop");
            $this->success[] = "Database created successfully";
        } catch(PDOException $e) {
            $this->errors[] = "Database creation failed: " . $e->getMessage();
        }
    }
    
    private function createTables() {
        $tables = [
            "CREATE TABLE IF NOT EXISTS users (
                UserID int(11) NOT NULL AUTO_INCREMENT,
                fName varchar(100) NOT NULL,
                lName varchar(100) NOT NULL,
                Email varchar(150) NOT NULL UNIQUE,
                Password varchar(255) NOT NULL,
                Role enum('Administrator','Sales Personnel','Inventory Manager','Customer') NOT NULL,
                PRIMARY KEY (UserID)
            )",
            "CREATE TABLE IF NOT EXISTS products (
                ProductID int(11) NOT NULL AUTO_INCREMENT,
                ProductName varchar(150) NOT NULL,
                Description text,
                Price decimal(10,2) NOT NULL,
                StockQuantity int(11) NOT NULL DEFAULT 0,
                PRIMARY KEY (ProductID)
            )",
            "CREATE TABLE IF NOT EXISTS orders (
                OrderID int(11) NOT NULL AUTO_INCREMENT,
                Date datetime DEFAULT CURRENT_TIMESTAMP,
                UserID int(11) NOT NULL,
                TotalAmount decimal(10,2) NOT NULL,
                PRIMARY KEY (OrderID),
                FOREIGN KEY (UserID) REFERENCES users(UserID)
            )",
            "CREATE TABLE IF NOT EXISTS orderdetails (
                OrderDetailID int(11) NOT NULL AUTO_INCREMENT,
                OrderID int(11) NOT NULL,
                ProductID int(11) NOT NULL,
                Quantity int(11) NOT NULL,
                Price decimal(10,2) NOT NULL,
                PRIMARY KEY (OrderDetailID),
                FOREIGN KEY (OrderID) REFERENCES orders(OrderID),
                FOREIGN KEY (ProductID) REFERENCES products(ProductID)
            )",
            "CREATE TABLE IF NOT EXISTS session (
                SessionID varchar(255) NOT NULL,
                UserID int(11) NOT NULL,
                CreatedAt datetime DEFAULT CURRENT_TIMESTAMP,
                ExpiresAt datetime NOT NULL,
                PRIMARY KEY (SessionID),
                FOREIGN KEY (UserID) REFERENCES users(UserID)
            )"
        ];
        
        foreach ($tables as $sql) {
            try {
                $this->db->exec($sql);
                $this->success[] = "Table created successfully";
            } catch(PDOException $e) {
                $this->errors[] = "Table creation failed: " . $e->getMessage();
            }
        }
    }
    
    private function createProcedures() {
        $procedures = [
            "DROP PROCEDURE IF EXISTS LoginUser",
            "CREATE PROCEDURE LoginUser(
                IN p_Email VARCHAR(150),
                IN p_Password VARCHAR(255),
                OUT p_Role ENUM('Administrator','Sales Personnel','Inventory Manager','Customer'),
                OUT p_UserID INT
            )
            BEGIN
                DECLARE hashed_password VARCHAR(255);
                SELECT Password, Role, UserID INTO hashed_password, p_Role, p_UserID
                FROM Users
                WHERE Email = p_Email;
                
                IF hashed_password != SHA2(p_Password, 256) THEN
                    SET p_UserID = NULL;
                    SET p_Role = NULL;
                END IF;
            END",
            
            "DROP PROCEDURE IF EXISTS RegisterUser",
            "CREATE PROCEDURE RegisterUser(
                IN p_fName VARCHAR(100),
                IN p_lName VARCHAR(100),
                IN p_Email VARCHAR(150),
                IN p_Password VARCHAR(255),
                IN p_Role ENUM('Administrator','Sales Personnel','Inventory Manager','Customer')
            )
            BEGIN
                INSERT INTO Users (fName, lName, Email, Password, Role)
                VALUES (p_fName, p_lName, p_Email, SHA2(p_Password, 256), p_Role);
            END",
            
            "DROP PROCEDURE IF EXISTS AssignRole",
            "CREATE PROCEDURE AssignRole(
                IN p_UserID INT,
                IN p_Role ENUM('Administrator','Sales Personnel','Inventory Manager','Customer')
            )
            BEGIN
                UPDATE Users SET Role = p_Role WHERE UserID = p_UserID;
            END"
        ];
        
        foreach ($procedures as $sql) {
            try {
                $this->db->exec($sql);
                $this->success[] = "Procedure created successfully";
            } catch(PDOException $e) {
                $this->errors[] = "Procedure creation failed: " . $e->getMessage();
            }
        }
    }
    
    private function insertTestData() {
        try {
            // Insert admin user
            $stmt = $this->db->prepare("CALL RegisterUser(?, ?, ?, ?, ?)");
            $stmt->execute([
                'Admin',
                'User',
                'admin@example.com',
                'password123',
                'Administrator'
            ]);
            
            // Insert test products
            $products = [
                ['Product A', 'Description of Product A', 100.00, 50],
                ['Product B', 'Description of Product B', 200.00, 30],
                ['Product C', 'Description of Product C', 150.00, 20]
            ];
            
            $stmt = $this->db->prepare("INSERT INTO products (ProductName, Description, Price, StockQuantity) VALUES (?, ?, ?, ?)");
            foreach ($products as $product) {
                $stmt->execute($product);
            }
            
            $this->success[] = "Test data inserted successfully";
        } catch(PDOException $e) {
            $this->errors[] = "Test data insertion failed: " . $e->getMessage();
        }
    }
    
    private function checkFilePermissions() {
        $directories = [
            '.',
            './admin',
            './orders',
            './inventory',
            './tests'
        ];
        
        foreach ($directories as $dir) {
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
                $this->success[] = "Created directory: $dir";
            }
        }
    }
    
    private function displayResults() {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>QuickShop Deployment Results</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body>
            <div class="container mt-4">
                <h2>Deployment Results</h2>
                
                <?php if (!empty($this->success)): ?>
                    <h3 class="text-success">Successful Operations:</h3>
                    <ul class="list-group mb-4">
                        <?php foreach ($this->success as $message): ?>
                            <li class="list-group-item text-success"><?= htmlspecialchars($message) ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
                
                <?php if (!empty($this->errors)): ?>
                    <h3 class="text-danger">Errors:</h3>
                    <ul class="list-group mb-4">
                        <?php foreach ($this->errors as $error): ?>
                            <li class="list-group-item text-danger"><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
                
                <div class="alert alert-info">
                    <h4>Next Steps:</h4>
                    <ol>
                        <li>Access the application at: <a href="../index.php">http://localhost/quickshop/</a></li>
                        <li>Login with admin credentials:
                            <ul>
                                <li>Email: admin@example.com</li>
                                <li>Password: password123</li>
                            </ul>
                        </li>
                        <li>Test different user roles and functionalities</li>
                    </ol>
                </div>
            </div>
        </body>
        </html>
        <?php
    }
}

// Run deployment
$deployer = new Deployer();
$deployer->deploy();