<?php
// tests/sqli_test.php
require_once '../config.php';

class SQLInjectionTester {
    private $db;
    private $testResults = [];
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function runTests() {
        // Test 1: Login Form SQL Injection
        $this->testLoginInjection();
        
        // Test 2: Product Search SQL Injection
        $this->testProductSearchInjection();
        
        // Test 3: User Registration SQL Injection
        $this->testRegistrationInjection();
        
        // Test 4: Order Details SQL Injection
        $this->testOrderDetailsInjection();
        
        $this->displayResults();
    }
    
    private function testLoginInjection() {
        $auth = new Auth();
        
        // Test Case 1: Basic SQL Injection
        $result1 = $auth->login("' OR '1'='1", "anything");
        $this->logResult(
            "Basic Login Bypass Prevention",
            "' OR '1'='1",
            !$result1,
            "Prevents basic SQL injection login bypass"
        );
        
        // Test Case 2: Union-Based Injection
        $result2 = $auth->login("' UNION SELECT 1,1,'admin','admin' -- ", "anything");
        $this->logResult(
            "Union-Based Login Attack Prevention",
            "' UNION SELECT...",
            !$result2,
            "Prevents UNION-based SQL injection attacks"
        );
        
        // Test Case 3: Time-Based Blind Injection
        $start = microtime(true);
        $auth->login("' OR SLEEP(2) AND '1'='1", "anything");
        $duration = microtime(true) - $start;
        $this->logResult(
            "Time-Based Injection Prevention",
            "' OR SLEEP(2)...",
            $duration < 2,
            "Prevents time-based blind SQL injection"
        );
    }
    
    private function testProductSearchInjection() {
        // Test Case 4: Product Search Injection
        $maliciousInput = "1'; DROP TABLE products; --";
        try {
            $stmt = $this->db->prepare("CALL SecureQuery(?)");
            $stmt->execute([$maliciousInput]);
            $this->logResult(
                "Product Search Protection",
                $maliciousInput,
                true,
                "Prevents malicious table dropping through search"
            );
        } catch (Exception $e) {
            $this->logResult(
                "Product Search Protection",
                $maliciousInput,
                false,
                "Error: " . $e->getMessage()
            );
        }
    }
    
    private function testRegistrationInjection() {
        $auth = new Auth();
        
        // Test Case 5: Registration Form Injection
        $maliciousEmail = "test@test.com'; UPDATE users SET role='Administrator';--";
        $result = $auth->register(
            "Test",
            "User",
            $maliciousEmail,
            "password123"
        );
        
        // Verify role wasn't changed
        $stmt = $this->db->prepare("SELECT role FROM users WHERE email = ?");
        $stmt->execute(["test@test.com"]);
        $user = $stmt->fetch();
        
        $this->logResult(
            "Registration Form Protection",
            $maliciousEmail,
            $user['role'] === 'Customer',
            "Prevents role escalation through registration"
        );
    }
    
    private function testOrderDetailsInjection() {
        // Test Case 6: Order Details Parameter Injection
        $maliciousOrderId = "1 OR 1=1";
        try {
            $stmt = $this->db->prepare(
                "SELECT * FROM orderdetails WHERE OrderID = ?"
            );
            $stmt->execute([$maliciousOrderId]);
            $this->logResult(
                "Order Details Protection",
                $maliciousOrderId,
                true,
                "Prevents unauthorized order details access"
            );
        } catch (Exception $e) {
            $this->logResult(
                "Order Details Protection",
                $maliciousOrderId,
                false,
                "Error: " . $e->getMessage()
            );
        }
    }
    
    private function logResult($testName, $input, $passed, $description) {
        $this->testResults[] = [
            'name' => $testName,
            'input' => $input,
            'passed' => $passed,
            'description' => $description
        ];
    }
    
    private function displayResults() {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>SQL Injection Test Results</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body>
            <div class="container mt-4">
                <h2>SQL Injection Prevention Test Results</h2>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Test Name</th>
                                <th>Malicious Input</th>
                                <th>Status</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($this->testResults as $result): ?>
                                <tr>
                                    <td><?= htmlspecialchars($result['name']) ?></td>
                                    <td><code><?= htmlspecialchars($result['input']) ?></code></td>
                                    <td>
                                        <?php if ($result['passed']): ?>
                                            <span class="badge bg-success">PASSED</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">FAILED</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($result['description']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="mt-4">
                    <h3>Security Measures Implemented</h3>
                    <ul>
                        <li>Prepared Statements: All database queries use parameterized queries</li>
                        <li>Stored Procedures: Critical operations are encapsulated in stored procedures</li>
                        <li>Input Validation: All user inputs are validated before processing</li>
                        <li>Parameter Binding: Query parameters are properly bound to prevent injection</li>
                        <li>Error Handling: Secure error handling prevents information leakage</li>
                        <li>Role-Based Access: Strict permission checking prevents unauthorized access</li>
                    </ul>
                </div>
            </div>
        </body>
        </html>
        <?php
    }
}

// Run the tests
$tester = new SQLInjectionTester();
$tester->runTests();