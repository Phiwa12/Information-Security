<?php
// orders/history.php
session_start();
require_once '../config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$isSecure = isset($_GET['secure']) ? true : false;

// Get orders
if ($isSecure) {
    // Secure version using prepared statements
    $db = Database::getInstance()->getConnection();
    $stmt = $db->prepare("
        SELECT o.*, u.fName, u.lName 
        FROM orders o 
        JOIN users u ON o.UserID = u.UserID 
        WHERE o.UserID = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $orders = $stmt->fetchAll();
} else {
    // Insecure version vulnerable to SQL injection
    $db = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $userId = $_SESSION['user_id'];
    // Vulnerable to SQL injection through URL parameter
    if (isset($_GET['user_id'])) {
        $userId = $_GET['user_id'];
    }
    $query = "SELECT o.*, u.fName, u.lName 
              FROM orders o 
              JOIN users u ON o.UserID = u.UserID 
              WHERE o.UserID = $userId";
    $result = mysqli_query($db, $query);
    $orders = mysqli_fetch_all($result, MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order History - QuickShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include '../navbar.php'; ?>
    
    <div class="container mt-4">
        <!-- Security Toggle -->
        <div class="text-end mb-3">
            <a href="?<?= $isSecure ? '' : 'secure=1' ?>" 
               class="btn btn-<?= $isSecure ? 'success' : 'danger' ?>">
                Currently: <?= $isSecure ? 'Secure Mode' : 'Vulnerable Mode' ?>
            </a>
        </div>

        <h2>Order History</h2>

        <?php if (!$isSecure): ?>
            <div class="alert alert-warning">
                <h4>🔥 SQL Injection Possible!</h4>
                <p>Try adding this to the URL: <code>?user_id=1 OR 1=1</code></p>
                <p>This will show ALL orders in the system!</p>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Date</th>
                        <th>Customer</th>
                        <th>Total Amount</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?= htmlspecialchars($order['OrderID']) ?></td>
                            <td><?= htmlspecialchars($order['Date']) ?></td>
                            <td><?= htmlspecialchars($order['fName'] . ' ' . $order['lName']) ?></td>
                            <td>$<?= number_format($order['TotalAmount'], 2) ?></td>
                            <td>
                                <a href="view_order.php?id=<?= $order['OrderID'] ?>" 
                                   class="btn btn-info btn-sm">View Details</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>