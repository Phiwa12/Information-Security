<?php
// navbar.php - Include this in all pages
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id']) && basename($_SERVER['PHP_SELF']) != 'login.php' && basename($_SERVER['PHP_SELF']) != 'register.php') {
    header('Location: login.php');
    exit;
}
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="index.php">QuickShop</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <?php if (isset($_SESSION['user_id'])): ?>
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="products.php">Products</a>
                    </li>
                    <?php if ($_SESSION['role'] === 'Administrator'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="admin/users.php">Manage Users</a>
                        </li>
                    <?php endif; ?>
                    
                    <?php if (in_array($_SESSION['role'], ['Administrator', 'Sales Personnel'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="orders/manage.php">Manage Orders</a>
                        </li>
                    <?php endif; ?>
                    
                    <?php if (in_array($_SESSION['role'], ['Administrator', 'Inventory Manager'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="inventory/manage.php">Inventory</a>
                        </li>
                    <?php endif; ?>
                    
                    <?php if ($_SESSION['role'] === 'Customer'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="cart.php">
                                Cart <?php if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                                    <span class="badge bg-primary"><?= array_sum($_SESSION['cart']) ?></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="orders/history.php">My Orders</a>
                        </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">Welcome, <?= htmlspecialchars($_SESSION['email']) ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</nav>