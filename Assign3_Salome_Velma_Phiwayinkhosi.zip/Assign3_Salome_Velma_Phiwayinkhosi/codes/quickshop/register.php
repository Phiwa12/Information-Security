<?php
// register.php
session_start();
require_once 'config.php';

// Toggle between secure and insecure versions
$isSecure = isset($_GET['secure']) ? true : false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = $_POST['fname'] ?? '';
    $lname = $_POST['lname'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'Customer';
    
    if ($isSecure) {
        // Secure version using prepared statements
        $auth = new Auth();
        if ($auth->register($fname, $lname, $email, $password, $role)) {
            $_SESSION['success'] = "Registration successful! Please login.";
            header('Location: login.php');
            exit;
        } else {
            $error = "Registration failed. Email might already be in use.";
        }
    } else {
        // Insecure version vulnerable to SQL injection
        $db = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        $query = "INSERT INTO users (fName, lName, Email, Password, Role) 
                 VALUES ('$fname', '$lname', '$email', '$password', '$role')";
        if (mysqli_query($db, $query)) {
            $_SESSION['success'] = "Registration successful! Please login.";
            header('Location: login.php');
            exit;
        } else {
            $error = "Registration failed: " . mysqli_error($db);
        }
        mysqli_close($db);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - QuickShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <!-- Security Toggle Button -->
        <div class="text-end mb-3">
            <a href="?<?= $isSecure ? '' : 'secure=1' ?>" class="btn btn-<?= $isSecure ? 'success' : 'danger' ?>">
                Currently: <?= $isSecure ? 'Secure Version' : 'Insecure Version' ?>
            </a>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Register</h3>
                    </div>
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger"><?= $error ?></div>
                        <?php endif; ?>
                        
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="fname" class="form-label">First Name</label>
                                <input type="text" class="form-control" id="fname" name="fname" required>
                            </div>
                            <div class="mb-3">
                                <label for="lname" class="form-label">Last Name</label>
                                <input type="text" class="form-control" id="lname" name="lname" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <div class="mb-3">
                                <label for="role" class="form-label">Role</label>
                                <select class="form-control" id="role" name="role" required>
                                    <option value="Administrator">Administrator</option>
                                    <option value="Sales Personnel">Sales Personnel</option>
                                    <option value="Inventory Manager">Inventory Manager</option>
                                    <option value="Customer" selected>Customer</option>
                                </select>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">Register</button>
                            </div>
                        </form>
                        <div class="mt-3 text-center">
                            <p>Already have an account? <a href="login.php">Login here</a></p>
                        </div>
                    </div>
                </div>
                
                <?php if (!$isSecure): ?>
                    <div class="alert alert-warning mt-3">
                        <h4>⚠️ Warning: Insecure Version</h4>
                        <p>This version is vulnerable to SQL injection. Try registering with malicious input like:</p>
                        <code>test@test.com', 'pass', 'Administrator'); DROP TABLE users; --</code>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>