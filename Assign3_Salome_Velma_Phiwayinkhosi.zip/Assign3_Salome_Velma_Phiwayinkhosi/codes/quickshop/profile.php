<?php
// profile.php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$isSecure = isset($_GET['secure']) ? true : false;
$message = '';

// Get user data
if ($isSecure) {
    // Secure version
    $db = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $stmt = $db->prepare("SELECT * FROM users WHERE UserID = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
} else {
    // Vulnerable version
    $db = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $id = $_GET['id'] ?? $_SESSION['user_id'];
    $query = "SELECT * FROM users WHERE UserID = $id";
    $result = mysqli_query($db, $query);
    $user = mysqli_fetch_assoc($result);
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    
    if ($isSecure) {
        // Secure version
        $stmt = $db->prepare("UPDATE users SET fName = ?, lName = ?, Email = ? WHERE UserID = ?");
        if($stmt->execute([$fname, $lname, $email, $_SESSION['user_id']])) {
            $message = "Profile updated successfully!";
        }
    } else {
        // Vulnerable version
        $query = "UPDATE users SET fName = '$fname', lName = '$lname', Email = '$email' 
                 WHERE UserID = " . $_SESSION['user_id'];
        if(mysqli_query($db, $query)) {
            $message = "Profile updated successfully!";
        }
        $executed_query = $query; // Store for display
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile - QuickShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container mt-4">
        <!-- Security Toggle -->
        <div class="text-end mb-3">
            <a href="?<?= $isSecure ? '' : 'secure=1' ?>" 
               class="btn btn-<?= $isSecure ? 'success' : 'danger' ?>">
                Mode: <?= $isSecure ? 'Secure' : 'Vulnerable' ?>
            </a>
        </div>

        <?php if (!$isSecure): ?>
            <div class="alert alert-danger">
                <h4>🔥 Try These Attacks:</h4>
                
                <p><strong>1. View All Users:</strong><br>
                Click here: <a href="?id=1 OR 1=1" class="text-danger">?id=1 OR 1=1</a></p>
                
                <p><strong>2. Elevate to Admin:</strong><br>
                Enter in First Name: <code>test', Role='Administrator'--</code></p>
                
                <p><strong>3. Modify Other Users:</strong><br>
                Enter in First Name: <code>test', Email='hacked@test.com' WHERE UserID=1--</code></p>
                
                <?php if (isset($executed_query)): ?>
                    <p><strong>Last Executed Query:</strong><br>
                    <code><?= htmlspecialchars($executed_query) ?></code></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if ($message): ?>
            <div class="alert alert-info"><?= $message ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h3>Update Profile</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">First Name</label>
                        <input type="text" name="fname" class="form-control" 
                               value="<?= $isSecure ? htmlspecialchars($user['fName']) : $user['fName'] ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Last Name</label>
                        <input type="text" name="lname" class="form-control" 
                               value="<?= $isSecure ? htmlspecialchars($user['lName']) : $user['lName'] ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="text" name="email" class="form-control" 
                               value="<?= $isSecure ? htmlspecialchars($user['Email']) : $user['Email'] ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Update Profile</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>