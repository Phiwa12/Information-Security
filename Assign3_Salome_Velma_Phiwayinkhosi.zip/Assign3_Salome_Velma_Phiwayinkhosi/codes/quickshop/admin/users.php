<?php
// admin/users.php
session_start();
require_once '../config.php';

// Ensure only administrators can access this page
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Administrator') {
    header('Location: ../index.php');
    exit;
}

class UserManager {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function getAllUsers() {
        $stmt = $this->db->prepare("SELECT UserID, fName, lName, Email, Role FROM users ORDER BY Role, lName, fName");
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    public function updateUserRole($userId, $role) {
        $stmt = $this->db->prepare("CALL AssignRole(?, ?)");
        return $stmt->execute([$userId, $role]);
    }
    
    public function deleteUser($userId) {
        // First check if user has any orders
        $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM orders WHERE UserID = ?");
        $stmt->execute([$userId]);
        $result = $stmt->fetch();
        
        if ($result['count'] > 0) {
            throw new Exception('Cannot delete user with existing orders');
        }
        
        // Delete user's sessions
        $stmt = $this->db->prepare("DELETE FROM session WHERE UserID = ?");
        $stmt->execute([$userId]);
        
        // Delete the user
        $stmt = $this->db->prepare("DELETE FROM users WHERE UserID = ?");
        return $stmt->execute([$userId]);
    }
}

$userManager = new UserManager();

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    try {
        switch ($_POST['action']) {
            case 'update_role':
                $success = $userManager->updateUserRole(
                    $_POST['user_id'],
                    $_POST['role']
                );
                echo json_encode(['success' => $success]);
                break;
                
            case 'delete_user':
                $success = $userManager->deleteUser($_POST['user_id']);
                echo json_encode(['success' => $success]);
                break;
                
            default:
                throw new Exception('Invalid action');
        }
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

$users = $userManager->getAllUsers();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Management - QuickShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include '../navbar.php'; ?>
    
    <div class="container mt-4">
        <h2>User Management</h2>
        
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?= htmlspecialchars($user['fName'] . ' ' . $user['lName']) ?></td>
                            <td><?= htmlspecialchars($user['Email']) ?></td>
                            <td>
                                <select class="form-select role-select" 
                                    data-user-id="<?= $user['UserID'] ?>">
                                    <?php foreach (['Administrator', 'Sales Personnel', 
                                        'Inventory Manager', 'Customer'] as $role): ?>
                                        <option value="<?= $role ?>" 
                                            <?= $role === $user['Role'] ? 'selected' : '' ?>>
                                            <?= $role ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-danger delete-user" 
                                    data-user-id="<?= $user['UserID'] ?>">
                                    Delete
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Handle role changes
            document.querySelectorAll('.role-select').forEach(select => {
                select.addEventListener('change', async function() {
                    const userId = this.dataset.userId;
                    const newRole = this.value;
                    
                    if (!confirm(`Are you sure you want to change this user's role to ${newRole}?`)) {
                        this.value = this.getAttribute('data-original-value');
                        return;
                    }
                    
                    try {
                        const response = await fetch('users.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                            },
                            body: `action=update_role&user_id=${userId}&role=${newRole}`
                        });
                        
                        const data = await response.json();
                        if (!data.success) {
                            throw new Error(data.error || 'Failed to update role');
                        }
                        
                        this.setAttribute('data-original-value', newRole);
                    } catch (error) {
                        alert(error.message);
                        this.value = this.getAttribute('data-original-value');
                    }
                });
                
                // Store original value
                select.setAttribute('data-original-value', select.value);
            });
            
            // Handle user deletion
            document.querySelectorAll('.delete-user').forEach(button => {
                button.addEventListener('click', async function() {
                    const userId = this.dataset.userId;
                    
                    if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
                        return;
                    }
                    
                    try {
                        const response = await fetch('users.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                            },
                            body: `action=delete_user&user_id=${userId}`
                        });
                        
                        const data = await response.json();
                        if (!data.success) {
                            throw new Error(data.error || 'Failed to delete user');
                        }
                        
                        // Remove the row from the table
                        this.closest('tr').remove();
                    } catch (error) {
                        alert(error.message);
                    }
                });
            });
        });
    </script>
</body>
</html>