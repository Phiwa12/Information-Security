-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2024 at 08:12 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quickshop`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `AssignRole` (IN `p_UserID` INT, IN `p_Role` ENUM('Administrator','Sales Personnel','Inventory Manager','Customer'))   BEGIN
                UPDATE Users SET Role = p_Role WHERE UserID = p_UserID;
            END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `GenerateSecurityAuditReport` ()   BEGIN
    -- Summary of all security events
    SELECT 'Overall Security Summary' as ReportTitle,
        EventType,
        Status,
        COUNT(*) as Count
    FROM SecurityAuditLog
    GROUP BY EventType, Status;
    
    -- Recent suspicious activities
    SELECT 'Recent Suspicious Activities' as ReportTitle,
        Timestamp,
        IPAddress,
        QueryAttempt,
        Status
    FROM SecurityAuditLog
    WHERE Status = 'SUSPICIOUS'
    ORDER BY Timestamp DESC
    LIMIT 10;
    
    -- Success rate of security measures
    SELECT 'Security Effectiveness' as ReportTitle,
        ROUND((COUNT(CASE WHEN Status = 'SUSPICIOUS' THEN 1 END) * 100.0 / 
        NULLIF(COUNT(*), 0)), 2) as BlockRate
    FROM SecurityAuditLog;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `LoginUser` (IN `p_Email` VARCHAR(150), IN `p_Password` VARCHAR(255), OUT `p_Role` ENUM('Administrator','Sales Personnel','Inventory Manager','Customer'), OUT `p_UserID` INT)   BEGIN
                DECLARE hashed_password VARCHAR(255);
                SELECT Password, Role, UserID INTO hashed_password, p_Role, p_UserID
                FROM Users
                WHERE Email = p_Email;
                
                IF hashed_password != SHA2(p_Password, 256) THEN
                    SET p_UserID = NULL;
                    SET p_Role = NULL;
                END IF;
            END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `LogSecurityEvent` (IN `p_EventType` VARCHAR(50), IN `p_UserID` INT, IN `p_IPAddress` VARCHAR(45), IN `p_QueryAttempt` TEXT, IN `p_RequestData` TEXT, IN `p_Status` VARCHAR(20))   BEGIN
    INSERT INTO SecurityAuditLog (EventType, UserID, IPAddress, QueryAttempt, RequestData, Status)
    VALUES (p_EventType, p_UserID, p_IPAddress, p_QueryAttempt, p_RequestData, p_Status);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `MonitorSuspiciousActivity` ()   BEGIN
    -- Find IPs with multiple suspicious attempts
    SELECT 
        IPAddress,
        COUNT(*) as AttemptCount,
        MAX(Timestamp) as LastAttempt
    FROM SecurityAuditLog
    WHERE Status = 'SUSPICIOUS'
    AND Timestamp >= NOW() - INTERVAL 1 HOUR
    GROUP BY IPAddress
    HAVING COUNT(*) >= 3;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `RegisterUser` (IN `p_fName` VARCHAR(100), IN `p_lName` VARCHAR(100), IN `p_Email` VARCHAR(150), IN `p_Password` VARCHAR(255), IN `p_Role` ENUM('Administrator','Sales Personnel','Inventory Manager','Customer'))   BEGIN
                INSERT INTO Users (fName, lName, Email, Password, Role)
                VALUES (p_fName, p_lName, p_Email, SHA2(p_Password, 256), p_Role);
            END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `RunSecurityTestSuite` ()   BEGIN
    -- Test Cases Array 
    
    -- 1. Basic SQL Injection Patterns
    CALL SecureProductSearch(''' OR ''''=''', 1, '192.168.1.1');
    CALL SecureProductSearch('" OR ""="', 1, '192.168.1.1');
    
    -- 2. UNION-based Attacks
    CALL SecureProductSearch('UNION SELECT password FROM users', 1, '192.168.1.2');
    CALL SecureProductSearch('UNION ALL SELECT NULL--', 1, '192.168.1.2');
    
    -- 3. Valid Inputs 
    CALL SecureProductSearch('Phone', 1, '192.168.1.6');
    CALL SecureProductSearch('Laptop', 1, '192.168.1.6');
    
    -- Generate Security Report
    SELECT 
        'Security Test Suite Complete' as Status,
        (SELECT COUNT(*) FROM SecurityAuditLog WHERE Status = 'SUSPICIOUS') as BlockedAttempts,
        (SELECT COUNT(*) FROM SecurityAuditLog WHERE Status = 'SUCCESS') as SuccessfulQueries;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SecureProductSearch` (IN `p_SearchTerm` VARCHAR(255), IN `p_UserID` INT, IN `p_IPAddress` VARCHAR(45))   BEGIN
    DECLARE is_valid BOOLEAN;
    
    -- Validate input
    SET is_valid = ValidateInputString(p_SearchTerm);
    
    -- Log the attempt
    CALL LogSecurityEvent(
        'SECURITY_TEST',
        p_UserID,
        p_IPAddress,
        p_SearchTerm,
        NULL,
        IF(is_valid, 'SUCCESS', 'SUSPICIOUS')
    );
    
    -- Only proceed if input is valid
    IF is_valid THEN
        SELECT 
            ProductID,
            ProductName,
            Description,
            Price,
            StockQuantity
        FROM products 
        WHERE ProductName LIKE CONCAT('%', p_SearchTerm, '%')
        OR Description LIKE CONCAT('%', p_SearchTerm, '%');
    ELSE
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid input detected';
    END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `SecureQuery` (IN `p_ProductID` INT)   BEGIN
    SELECT * FROM Products WHERE ProductID = p_ProductID;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VulnerableProductSearch` (IN `p_SearchTerm` VARCHAR(255))   BEGIN
    SET @sql = CONCAT("SELECT * FROM products WHERE ProductName LIKE '%", p_SearchTerm, "%'");
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `ValidateInputString` (`input` TEXT) RETURNS TINYINT(1) DETERMINISTIC BEGIN
    RETURN input NOT REGEXP '[\\\\\'\"=\\-#]' 
           AND input NOT REGEXP '(?i)(SELECT|INSERT|UPDATE|DELETE|DROP|UNION|INTO|LOAD_FILE)';
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `OrderDetailID` int(11) NOT NULL,
  `OrderID` int(11) NOT NULL,
  `ProductID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`OrderDetailID`, `OrderID`, `ProductID`, `Quantity`, `Price`) VALUES
(1, 1, 1, 1, 100.00),
(2, 1, 2, 1, 200.00),
(3, 1, 3, 1, 150.00),
(4, 2, 7, 4, 89.99),
(5, 2, 6, 2, 299.99),
(6, 2, 4, 2, 1299.99),
(7, 2, 1, 2, 100.00),
(8, 2, 2, 1, 200.00);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderID` int(11) NOT NULL,
  `Date` datetime DEFAULT current_timestamp(),
  `UserID` int(11) NOT NULL,
  `TotalAmount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderID`, `Date`, `UserID`, `TotalAmount`) VALUES
(1, '2024-11-21 12:56:55', 12, 450.00),
(2, '2024-11-21 14:35:18', 12, 3959.92);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ProductID` int(11) NOT NULL,
  `ProductName` varchar(150) NOT NULL,
  `Description` text DEFAULT NULL,
  `Price` decimal(10,2) NOT NULL,
  `StockQuantity` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ProductID`, `ProductName`, `Description`, `Price`, `StockQuantity`) VALUES
(1, 'Product A', 'Description of Product A', 100.00, 47),
(2, 'Product B', 'Description of Product B', 200.00, 28),
(3, 'Product C', 'Description of Product C', 150.00, 19),
(4, 'Laptop Pro X', 'High-performance laptop with 16GB RAM', 1299.99, 23),
(5, 'Wireless Mouse', 'Ergonomic wireless mouse with long battery life', 29.99, 100),
(6, 'HD Monitor 27\"', '27-inch HD monitor with built-in speakers', 299.99, 38),
(7, 'Gaming Keyboard', 'Mechanical gaming keyboard with RGB', 89.99, 46),
(8, 'USB-C Hub', 'Multi-port USB-C hub with HDMI', 45.99, 75);

-- --------------------------------------------------------

--
-- Table structure for table `securityauditlog`
--

CREATE TABLE `securityauditlog` (
  `LogID` int(11) NOT NULL,
  `Timestamp` datetime DEFAULT current_timestamp(),
  `EventType` enum('LOGIN_ATTEMPT','SQLI_ATTEMPT','UNAUTHORIZED_ACCESS','DATA_MODIFICATION','SECURITY_TEST') DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `IPAddress` varchar(45) DEFAULT NULL,
  `QueryAttempt` text DEFAULT NULL,
  `RequestData` text DEFAULT NULL,
  `Status` enum('SUCCESS','FAILED','BLOCKED','SUSPICIOUS') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `securityauditlog`
--

INSERT INTO `securityauditlog` (`LogID`, `Timestamp`, `EventType`, `UserID`, `IPAddress`, `QueryAttempt`, `RequestData`, `Status`) VALUES
(1, '2024-11-20 21:43:53', 'SECURITY_TEST', 1, '127.0.0.1', 'Product A', NULL, 'SUCCESS'),
(2, '2024-11-20 21:45:05', 'SECURITY_TEST', 1, '127.0.0.1', 'x\' OR \'1\'=\'1', NULL, 'SUSPICIOUS'),
(3, '2024-11-20 21:46:09', 'SECURITY_TEST', 1, '127.0.0.1', 'x\' UNION SELECT ProductID, ProductName, Description, Price, StockQuantity FROM products--', NULL, 'SUSPICIOUS'),
(4, '2024-11-21 00:30:22', 'SECURITY_TEST', 1, '::1', '', NULL, 'SUCCESS'),
(5, '2024-11-21 00:30:22', 'SECURITY_TEST', 1, '::1', '', NULL, 'SUCCESS');

-- --------------------------------------------------------

--
-- Stand-in structure for view `securitysummary`
-- (See below for the actual view)
--
CREATE TABLE `securitysummary` (
`Date` date
,`EventType` enum('LOGIN_ATTEMPT','SQLI_ATTEMPT','UNAUTHORIZED_ACCESS','DATA_MODIFICATION','SECURITY_TEST')
,`Status` enum('SUCCESS','FAILED','BLOCKED','SUSPICIOUS')
,`EventCount` bigint(21)
,`IPAddress` varchar(45)
);

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE `session` (
  `SessionID` varchar(255) NOT NULL,
  `UserID` int(11) NOT NULL,
  `CreatedAt` datetime DEFAULT current_timestamp(),
  `ExpiresAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `session`
--

INSERT INTO `session` (`SessionID`, `UserID`, `CreatedAt`, `ExpiresAt`) VALUES
('cb87d2e5c7f5ed552d4d4f419f39ffdbfb68241c511361713048e5487e60a7f3', 13, '2024-11-21 13:04:13', '2024-11-22 13:04:13'),
('f4a8f40aa5b55405d775b39b1f577dfefea66b50f793af230fe9654018de5247', 13, '2024-11-21 14:10:47', '2024-11-22 14:10:47');

-- --------------------------------------------------------

--
-- Stand-in structure for view `suspiciousactivity`
-- (See below for the actual view)
--
CREATE TABLE `suspiciousactivity` (
`LogID` int(11)
,`Timestamp` datetime
,`EventType` enum('LOGIN_ATTEMPT','SQLI_ATTEMPT','UNAUTHORIZED_ACCESS','DATA_MODIFICATION','SECURITY_TEST')
,`UserID` int(11)
,`IPAddress` varchar(45)
,`QueryAttempt` text
,`RequestData` text
,`Status` enum('SUCCESS','FAILED','BLOCKED','SUSPICIOUS')
);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `fName` varchar(100) NOT NULL,
  `lName` varchar(100) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Role` enum('Administrator','Sales Personnel','Inventory Manager','Customer') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `fName`, `lName`, `Email`, `Password`, `Role`) VALUES
(1, 'Admin', 'User', 'admin@example.com', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'Administrator'),
(2, 'Sales', 'Person', 'sales@example.com', '6bc0a63cb29c92306020c0a6bbc358cc4628db277dc06e253535e126517ad637', 'Sales Personnel'),
(3, 'Inventory', 'Manager', 'inventory@example.com', 'cd63ef271f9f5c81c3ac9e24e544f7e982360ebc027bf4e6b6960485b13f89e7', 'Inventory Manager'),
(4, 'First', 'Customer', 'customer@example.com', 'b041c0aeb35bb0fa4aa668ca5a920b590196fdaf9a00eb852c9b7f4d123cc6d6', 'Customer'),
(7, 'Admin', 'User', 'admin@gmail.com', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'Administrator'),
(12, 'Phiwa', 'Lukhele', 'wendy@gmail.com', 'c92b7d920e182a10a786001a2c84d960a7b872bf7500f473d775fed80dabca0e', 'Customer'),
(13, 'Sally', 'John', 'sally@gmail.com', '5683da5ad1e52f096f47d95c4e1f24dde1cc7d67f0cb045fb632533a88b54a33', 'Customer'),
(18, 'Mwe', 'yup', 'test@test.com', '12345', 'Administrator'),
(19, 'Wanda', 'Luke', 'admin@lijahasiswa.com', '5bbd0ec7cfffbe9c7b8c2fdfd41a0925b9ce9fdf6ba32608aad5112732b94383', 'Administrator'),
(22, 'Kaluki', 'Mutemwa', 'mutemwa@gmail.com', 'Mutemwa_1212!@', 'Sales Personnel'),
(23, 'Ane', 'Sali', 'sali@gmail.com', 'c92b7d920e182a10a786001a2c84d960a7b872bf7500f473d775fed80dabca0e', 'Customer');

-- --------------------------------------------------------

--
-- Structure for view `securitysummary`
--
DROP TABLE IF EXISTS `securitysummary`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `securitysummary`  AS SELECT cast(`securityauditlog`.`Timestamp` as date) AS `Date`, `securityauditlog`.`EventType` AS `EventType`, `securityauditlog`.`Status` AS `Status`, count(0) AS `EventCount`, `securityauditlog`.`IPAddress` AS `IPAddress` FROM `securityauditlog` GROUP BY cast(`securityauditlog`.`Timestamp` as date), `securityauditlog`.`EventType`, `securityauditlog`.`Status`, `securityauditlog`.`IPAddress` ;

-- --------------------------------------------------------

--
-- Structure for view `suspiciousactivity`
--
DROP TABLE IF EXISTS `suspiciousactivity`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `suspiciousactivity`  AS SELECT `securityauditlog`.`LogID` AS `LogID`, `securityauditlog`.`Timestamp` AS `Timestamp`, `securityauditlog`.`EventType` AS `EventType`, `securityauditlog`.`UserID` AS `UserID`, `securityauditlog`.`IPAddress` AS `IPAddress`, `securityauditlog`.`QueryAttempt` AS `QueryAttempt`, `securityauditlog`.`RequestData` AS `RequestData`, `securityauditlog`.`Status` AS `Status` FROM `securityauditlog` WHERE `securityauditlog`.`Status` in ('FAILED','BLOCKED','SUSPICIOUS') ORDER BY `securityauditlog`.`Timestamp` DESC ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`OrderDetailID`),
  ADD KEY `OrderID` (`OrderID`),
  ADD KEY `ProductID` (`ProductID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ProductID`);

--
-- Indexes for table `securityauditlog`
--
ALTER TABLE `securityauditlog`
  ADD PRIMARY KEY (`LogID`);

--
-- Indexes for table `session`
--
ALTER TABLE `session`
  ADD PRIMARY KEY (`SessionID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orderdetails`
--
ALTER TABLE `orderdetails`
  MODIFY `OrderDetailID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `OrderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `ProductID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `securityauditlog`
--
ALTER TABLE `securityauditlog`
  MODIFY `LogID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD CONSTRAINT `orderdetails_ibfk_1` FOREIGN KEY (`OrderID`) REFERENCES `orders` (`OrderID`),
  ADD CONSTRAINT `orderdetails_ibfk_2` FOREIGN KEY (`ProductID`) REFERENCES `products` (`ProductID`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `session`
--
ALTER TABLE `session`
  ADD CONSTRAINT `session_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
