<?php
// cart.php
require_once 'config.php';
include 'navbar.php';

if ($_SESSION['role'] !== 'Customer') {
    header('Location: index.php');
    exit;
}

$db = Database::getInstance()->getConnection();

// Handle cart updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update'])) {
        foreach ($_POST['quantity'] as $productId => $quantity) {
            if ($quantity > 0) {
                $_SESSION['cart'][$productId] = min($quantity, 99); // Limit quantity
            } else {
                unset($_SESSION['cart'][$productId]);
            }
        }
    } elseif (isset($_POST['clear'])) {
        $_SESSION['cart'] = [];
    }
    header('Location: cart.php');
    exit;
}

// Get cart items
$cartItems = [];
$total = 0;

if (!empty($_SESSION['cart'])) {
    $productIds = array_keys($_SESSION['cart']);
    $placeholders = str_repeat('?,', count($productIds) - 1) . '?';
    
    $stmt = $db->prepare("SELECT * FROM products WHERE ProductID IN ($placeholders)");
    $stmt->execute($productIds);
    $products = $stmt->fetchAll();
    
    foreach ($products as $product) {
        $quantity = $_SESSION['cart'][$product['ProductID']];
        $subtotal = $product['Price'] * $quantity;
        $total += $subtotal;
        
        $cartItems[] = [
            'product' => $product,
            'quantity' => $quantity,
            'subtotal' => $subtotal
        ];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - QuickShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>Shopping Cart</h2>
        
        <?php if (empty($cartItems)): ?>
            <div class="alert alert-info">
                Your cart is empty. <a href="products.php">Continue shopping</a>
            </div>
        <?php else: ?>
            <form method="POST">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($cartItems as $item): ?>
                                <tr>
                                    <td><?= htmlspecialchars($item['product']['ProductName']) ?></td>
                                    <td>$<?= number_format($item['product']['Price'], 2) ?></td>
                                    <td>
                                        <input type="number" name="quantity[<?= $item['product']['ProductID'] ?>]" 
                                            value="<?= $item['quantity'] ?>" min="0" max="<?= $item['product']['StockQuantity'] ?>" 
                                            class="form-control" style="width: 100px">
                                    </td>
                                    <td>$<?= number_format($item['subtotal'], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <tr>
                                <td colspan="3" class="text-end"><strong>Total:</strong></td>
                                <td><strong>$<?= number_format($total, 2) ?></strong></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="d-flex justify-content-between">
                    <div>
                        <button type="submit" name="update" class="btn btn-secondary">Update Cart</button>
                        <button type="submit" name="clear" class="btn btn-warning" 
                            onclick="return confirm('Are you sure you want to clear your cart?')">
                            Clear Cart
                        </button>
                    </div>
                    <a href="checkout.php" class="btn btn-primary">Proceed to Checkout</a>
                </div>
            </form>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>