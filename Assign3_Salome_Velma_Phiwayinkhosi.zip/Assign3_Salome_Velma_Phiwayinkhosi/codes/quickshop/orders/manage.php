<?php
// orders/manage.php
session_start();
require_once '../config.php';

class OrderManager {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function getOrders($userId = null) {
        $sql = "SELECT o.*, u.fName, u.lName 
                FROM orders o 
                JOIN users u ON o.UserID = u.UserID ";
                
        if ($userId && $_SESSION['role'] === 'Customer') {
            $sql .= "WHERE o.UserID = ? ";
            $params = [$userId];
        } else {
            $params = [];
        }
        
        $sql .= "ORDER BY o.Date DESC";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    public function getOrderDetails($orderId) {
        Authorization::checkPermission('read_order_details');
        
        if ($_SESSION['role'] === 'Customer') {
            $stmt = $this->db->prepare("SELECT o.UserID 
                FROM orders o 
                WHERE o.OrderID = ?");
            $stmt->execute([$orderId]);
            $order = $stmt->fetch();
            
            if ($order['UserID'] !== $_SESSION['user_id']) {
                throw new Exception('Unauthorized access to order details');
            }
        }
        
        $stmt = $this->db->prepare("
            SELECT od.*, p.ProductName 
            FROM orderdetails od
            JOIN products p ON od.ProductID = p.ProductID
            WHERE od.OrderID = ?
        ");
        $stmt->execute([$orderId]);
        return $stmt->fetchAll();
    }
    
    public function createOrder($userId, $items) {
        $this->db->beginTransaction();
        
        try {
            // Calculate total amount
            $totalAmount = 0;
            foreach ($items as $item) {
                $stmt = $this->db->prepare("SELECT Price, StockQuantity FROM products WHERE ProductID = ?");
                $stmt->execute([$item['product_id']]);
                $product = $stmt->fetch();
                
                if ($product['StockQuantity'] < $item['quantity']) {
                    throw new Exception('Insufficient stock');
                }
                
                $totalAmount += $product['Price'] * $item['quantity'];
            }
            
            // Create order
            $stmt = $this->db->prepare("INSERT INTO orders (UserID, TotalAmount) VALUES (?, ?)");
            $stmt->execute([$userId, $totalAmount]);
            $orderId = $this->db->lastInsertId();
            
            // Create order details and update stock
            foreach ($items as $item) {
                $stmt = $this->db->prepare("INSERT INTO orderdetails 
                    (OrderID, ProductID, Quantity, Price) 
                    VALUES (?, ?, ?, 
                        (SELECT Price FROM products WHERE ProductID = ?))");
                $stmt->execute([
                    $orderId, 
                    $item['product_id'], 
                    $item['quantity'],
                    $item['product_id']
                ]);
                
                // Update stock
                $stmt = $this->db->prepare("UPDATE products 
                    SET StockQuantity = StockQuantity - ? 
                    WHERE ProductID = ?");
                $stmt->execute([$item['quantity'], $item['product_id']]);
            }
            
            $this->db->commit();
            return $orderId;
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
}

$orderManager = new OrderManager();

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    try {
        switch ($_POST['action']) {
            case 'get_order_details':
                Authorization::checkPermission('read_order_details');
                $details = $orderManager->getOrderDetails($_POST['order_id']);
                echo json_encode(['success' => true, 'details' => $details]);
                break;
                
            case 'create_order':
                Authorization::checkPermission('write_orders');
                $orderId = $orderManager->createOrder(
                    $_SESSION['user_id'],
                    json_decode($_POST['items'], true)
                );
                echo json_encode(['success' => true, 'order_id' => $orderId]);
                break;
                
            default:
                throw new Exception('Invalid action');
        }
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

// Get orders for display
$orders = $orderManager->getOrders(
    $_SESSION['role'] === 'Customer' ? $_SESSION['user_id'] : null
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Management - QuickShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include '../navbar.php'; ?>
    
    <div class="container mt-4">
        <h2>Order Management</h2>
        
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Date</th>
                        <th>Customer</th>
                        <th>Total Amount</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?= $order['OrderID'] ?></td>
                            <td><?= $order['Date'] ?></td>
                            <td><?= htmlspecialchars($order['fName'] . ' ' . $order['lName']) ?></td>
                            <td>$<?= number_format($order['TotalAmount'], 2) ?></td>
                            <td>
                                <button class="btn btn-sm btn-info view-details" 
                                    data-order-id="<?= $order['OrderID'] ?>">
                                    View Details
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Order Details Modal -->
    <div class="modal fade" id="orderDetailsModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Order Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody id="orderDetailsBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
       document.addEventListener('DOMContentLoaded', function() {
    const orderDetailsModal = new bootstrap.Modal(document.getElementById('orderDetailsModal'));
    
    // Handle viewing order details
    document.querySelectorAll('.view-details').forEach(button => {
        button.addEventListener('click', async function() {
            const orderId = this.dataset.orderId;
            
            try {
                const response = await fetch('manage.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=get_order_details&order_id=${orderId}`
                });
                
                const data = await response.json();
                if (!data.success) {
                    throw new Error(data.error || 'Failed to fetch order details');
                }
                
                // Populate modal with order details
                const tbody = document.getElementById('orderDetailsBody');
                tbody.innerHTML = '';
                
                let total = 0;
                data.details.forEach(detail => {
                    const subtotal = detail.Quantity * detail.Price;
                    total += subtotal;
                    
                    tbody.innerHTML += `
                        <tr>
                            <td>${detail.ProductName}</td>
                            <td>${detail.Quantity}</td>
                            <td>$${Number(detail.Price).toFixed(2)}</td>
                            <td>$${subtotal.toFixed(2)}</td>
                        </tr>
                    `;
                });
                
                // Add total row
                tbody.innerHTML += `
                    <tr>
                        <td colspan="3" class="text-end"><strong>Total:</strong></td>
                        <td><strong>$${total.toFixed(2)}</strong></td>
                    </tr>
                `;
                
                orderDetailsModal.show();
            } catch (error) {
                alert(error.message);
            }
        });
    });
});