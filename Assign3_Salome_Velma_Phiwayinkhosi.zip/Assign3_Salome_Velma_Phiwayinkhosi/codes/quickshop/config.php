<?php
// config.php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'quickshop');

// Database connection class with prepared statements
class Database {
    private $conn;
    private static $instance = null;
    
    private function __construct() {
        try {
            $this->conn = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME,
                DB_USER,
                DB_PASS
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->conn;
    }
}

// Authentication class
class Auth {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    public function login($email, $password) {
        try {
            $stmt = $this->db->prepare("CALL LoginUser(?, ?, @role, @userId)");
            $stmt->execute([$email, $password]);
            
            $result = $this->db->query("SELECT @role as role, @userId as userId")->fetch();
            
            if ($result['userId']) {
                session_start();
                $_SESSION['user_id'] = $result['userId'];
                $_SESSION['role'] = $result['role'];
                $_SESSION['email'] = $email;
                
                // Generate and store session token
                $token = bin2hex(random_bytes(32));
                $stmt = $this->db->prepare("INSERT INTO session (SessionID, UserID, ExpiresAt) 
                    VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 24 HOUR))");
                $stmt->execute([$token, $result['userId']]);
                
                $_SESSION['token'] = $token;
                return true;
            }
            return false;
        } catch(PDOException $e) {
            error_log("Login error: " . $e->getMessage());
            return false;
        }
    }
    
    public function register($fname, $lname, $email, $password, $role = 'Customer') {
        try {
            $stmt = $this->db->prepare("CALL RegisterUser(?, ?, ?, ?, ?)");
            return $stmt->execute([$fname, $lname, $email, $password, $role]);
        } catch(PDOException $e) {
            error_log("Registration error: " . $e->getMessage());
            return false;
        }
    }
    
    public function checkSession() {
        if (!isset($_SESSION['token']) || !isset($_SESSION['user_id'])) {
            return false;
        }
        
        $stmt = $this->db->prepare("SELECT * FROM session 
            WHERE SessionID = ? AND UserID = ? AND ExpiresAt > NOW()");
        $stmt->execute([$_SESSION['token'], $_SESSION['user_id']]);
        
        return $stmt->rowCount() > 0;
    }
    
    public function logout() {
        if (isset($_SESSION['token'])) {
            $stmt = $this->db->prepare("DELETE FROM session WHERE SessionID = ?");
            $stmt->execute([$_SESSION['token']]);
        }
        session_destroy();
    }
}

// Authorization class
class Authorization {
    private static $permissions = [
        'Administrator' => ['read_all', 'write_all', 'delete_all'],
        'Sales Personnel' => [
            'read_products',
            'read_orders',
            'write_orders',
            'read_order_details',
            'write_order_details'
        ],
        'Inventory Manager' => [
            'read_products',
            'write_products',
            'read_orders',
            'read_order_details'
        ],
        'Customer' => [
            'read_products',
            'read_own_orders',
            'read_own_order_details',
            'update_own_profile'
        ]
    ];
    
    public static function hasPermission($role, $permission) {
        if (!isset(self::$permissions[$role])) {
            return false;
        }
        
        if ($role === 'Administrator') {
            return true;
        }
        
        return in_array($permission, self::$permissions[$role]);
    }
    
    public static function checkPermission($permission) {
        if (!isset($_SESSION['role'])) {
            header('Location: login.php');
            exit;
        }
        
        if (!self::hasPermission($_SESSION['role'], $permission)) {
            header('HTTP/1.1 403 Forbidden');
            die('Access Denied');
        }
    }
}