<?php
// products.php
require_once 'config.php';
include 'navbar.php';

$db = Database::getInstance()->getConnection();

// Handle adding to cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    $productId = $_POST['product_id'];
    $quantity = $_POST['quantity'] ?? 1;
    
    if (!isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId] = 0;
    }
    $_SESSION['cart'][$productId] += $quantity;
    
    header('Location: products.php?added=1');
    exit;
}

// Get all products
$stmt = $db->prepare("SELECT * FROM products ORDER BY ProductName");
$stmt->execute();
$products = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - QuickShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <?php if (isset($_GET['added'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                Product added to cart successfully!
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <h2>Products</h2>
        
        <?php if (isset($_SESSION['role']) && in_array($_SESSION['role'], ['Administrator', 'Inventory Manager'])): ?>
            <div class="mb-3">
                <a href="inventory/add_product.php" class="btn btn-primary">Add New Product</a>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <?php foreach ($products as $product): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($product['ProductName']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($product['Description']) ?></p>
                            <p class="card-text">
                                <strong>Price:</strong> $<?= number_format($product['Price'], 2) ?>
                            </p>
                            <p class="card-text">
                                <strong>Stock:</strong> <?= $product['StockQuantity'] ?>
                            </p>
                            
                            <?php if ($_SESSION['role'] === 'Customer' && $product['StockQuantity'] > 0): ?>
                                <form method="POST" class="mt-auto">
                                    <input type="hidden" name="product_id" value="<?= $product['ProductID'] ?>">
                                    <div class="input-group mb-3">
                                        <input type="number" class="form-control" name="quantity" value="1" 
                                            min="1" max="<?= $product['StockQuantity'] ?>">
                                        <button type="submit" name="add_to_cart" class="btn btn-primary">
                                            Add to Cart
                                        </button>
                                    </div>
                                </form>
                            <?php elseif ($product['StockQuantity'] <= 0): ?>
                                <div class="text-danger">Out of Stock</div>
                            <?php endif; ?>
                            
                            <?php if (in_array($_SESSION['role'], ['Administrator', 'Inventory Manager'])): ?>
                                <div class="mt-2">
                                    <a href="inventory/edit_product.php?id=<?= $product['ProductID'] ?>" 
                                        class="btn btn-secondary">Edit</a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>