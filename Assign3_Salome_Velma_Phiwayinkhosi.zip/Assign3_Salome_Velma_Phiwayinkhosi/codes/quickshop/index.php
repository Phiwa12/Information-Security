<?php
// index.php
session_start();
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QuickShop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">QuickShop</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="products.php">Products</a>
                    </li>
                    <?php if ($_SESSION['role'] === 'Administrator'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="admin/users.php">Manage Users</a>
                        </li>
                    <?php endif; ?>
                    
                    <?php if (in_array($_SESSION['role'], ['Administrator', 'Sales Personnel'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="orders/manage.php">Manage Orders</a>
                        </li>
                    <?php endif; ?>
                    
                    <?php if ($_SESSION['role'] === 'Customer'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="orders/history.php">My Orders</a>
                        </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <span class="nav-link">Welcome, <?= htmlspecialchars($_SESSION['email']) ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="jumbotron">
            <h1>Welcome to QuickShop</h1>
            <p class="lead">You are logged in as: <?= htmlspecialchars($_SESSION['role']) ?></p>
            
            <div class="mt-4">
                <h2>Quick Actions</h2>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card mb-3">
                            <div class="card-body">
                                <h5 class="card-title">Products</h5>
                                <p class="card-text">Browse and manage products</p>
                                <a href="products.php" class="btn btn-primary">View Products</a>
                            </div>
                        </div>
                    </div>
                    
                    <?php if ($_SESSION['role'] === 'Customer'): ?>
                        <div class="col-md-4">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">My Orders</h5>
                                    <p class="card-text">View your order history</p>
                                    <a href="orders/history.php" class="btn btn-primary">View Orders</a>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($_SESSION['role'] === 'Administrator'): ?>
                        <div class="col-md-4">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">User Management</h5>
                                    <p class="card-text">Manage system users</p>
                                    <a href="admin/users.php" class="btn btn-primary">Manage Users</a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">Order Management</h5>
                                    <p class="card-text">Manage system orders</p>
                                    <a href="orders/manage.php" class="btn btn-primary">Manage Orders</a>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">Inventory</h5>
                                    <p class="card-text">Manage system inventory</p>
                                    <a href="inventory/manage.php" class="btn btn-primary">Manage Inventory</a>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if ($_SESSION['role'] === 'Sales Personnel'): ?>
                        

                        <div class="col-md-4">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">Order Management</h5>
                                    <p class="card-text">Manage system orders</p>
                                    <a href="orders/manage.php" class="btn btn-primary">Manage Orders</a>
                                </div>
                            </div>
                        </div>

                        
                    <?php endif; ?>

                    <?php if ($_SESSION['role'] === 'Inventory Manager'): ?>
                        

                        <div class="col-md-4">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <h5 class="card-title">Inventory Management</h5>
                                    <p class="card-text">Manage system inventory</p>
                                    <a href="inventory/manage.php" class="btn btn-primary">Manage Inventory</a>
                                </div>
                            </div>
                        </div>

                        
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>